# External Dependencies

This is where vendored dependencies live. They may have separate licenses, see
the source files themselves.

  - `json11` (MIT) - <https://github.com/dropbox/json11>
