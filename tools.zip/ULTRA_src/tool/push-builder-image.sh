#!/usr/bin/env sh

set -e

docker push traviswheelerlab/ultra-build:latest
